import asyncio
import logging
import aiosqlite
from aiogram import Bot, Dispatcher, types
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from config import *

# Logging setup
logging.basicConfig(level=logging.INFO)

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN, parse_mode=ParseMode.HTML)
dp = Dispatcher()


# Initialize the database
async def init_db():
    async with aiosqlite.connect("users.db") as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                balance REAL DEFAULT 0,
                last_bonus INTEGER DEFAULT 0,
                referrals INTEGER DEFAULT 0
            )
        """)
        await db.commit()


# /start command
@dp.message(CommandStart())
async def on_start(message: types.Message):
    user_id = message.from_user.id
    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if not user:
            await db.execute("INSERT INTO users (user_id, balance) VALUES (?, ?)", (user_id, JOIN_BONUS))
            await db.commit()
            await message.answer("🎉 Welcome! You received 1 TON as a joining bonus.")
        else:
            await message.answer("👋 You already joined. Use /balance to check your TON.")


# /balance command
@dp.message(Command(commands=["balance"]))
async def check_balance(message: types.Message):
    user_id = message.from_user.id
    async with aiosqlite.connect("users.db") as db:
        cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        user = await cursor.fetchone()
        if user:
            await message.answer(f"💰 Your current balance: <b>{user[0]} TON</b>")
        else:
            await message.answer("❌ You're not registered. Send /start to join.")


# Start polling
async def main():
    await init_db()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
